● Por que você escolheu esse projeto.
Escolhi porque me identifiquei com a proposta. Amo futebol, amo copa do mundo e me senti muito a vontade escolhendo esse prohjeto. Tudo de futebol sobretudo fora do campo me interessa muito.

● Principais dificuldades que encontrou durante o desenvolvimento.
Paciencia para criar cada seção, cada container, cada propriedade em css é algo muito cansativo e massante, sobretudo quando voce "copia" a página de outro já pronta. Esse projeto precisou que eu entendesse as parte principais da pagina e depois cada detalhe que eu precisei correr atrás.

● Estrutura de pastas que você adotou e por que.
como eu dependia de muitas imagens, decidi colocar as imagens ícones e figuras dentro de pastas para ficar mais fácil o gerenciamento das imagens.
